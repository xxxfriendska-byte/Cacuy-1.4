# Tidak ada rule khusus yang diperlukan untuk WebView + overlay service sederhana ini.
