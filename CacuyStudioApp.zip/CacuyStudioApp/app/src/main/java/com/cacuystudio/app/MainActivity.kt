package com.cacuystudio.app

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Rational
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // Dipanggil setelah user kembali dari halaman "Display over other apps" di Settings
    // (jalur fallback ini hanya dipakai kalau perangkat TIDAK mendukung PiP).
    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                startBubbleOverlayAndMinimize()
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            allowFileAccess = true
            databaseEnabled = true
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(WebAppBridge(), "AndroidBridge")

        // File HTML app disalin ke assets/www/ (lihat README).
        webView.loadUrl("file:///android_asset/www/cacuy-studio-app.html")

        BubbleService.hide(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        BubbleService.hide(this)
    }

    /** Dipanggil dari JS (tombol "Kecilkan aplikasi" di HTML) lewat AndroidBridge.minimizeToOverlay() */
    fun requestMinimizeToBubble() {
        // 1) Cara utama & resmi: Picture-in-Picture bawaan Android -- jendela mini
        //    mengambang berisi TAMPILAN ASLI app ini, tetap di atas app lain, TANPA
        //    perlu minta izin khusus (didukung sejak Android 8, dan HP masa kini
        //    hampir semua mendukungnya).
        if (tryEnterPictureInPicture()) return

        // 2) Fallback: kalau perangkat tidak mendukung PiP sama sekali, pakai bubble
        //    overlay kustom (butuh izin "Display over other apps").
        if (Settings.canDrawOverlays(this)) {
            startBubbleOverlayAndMinimize()
        } else {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun tryEnterPictureInPicture(): Boolean {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            return false
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Rasio 9:16 -> jendela mini portrait, mirip pratinjau video/konten di app.
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(9, 16))
                    .build()
                enterPictureInPictureMode(params)
            } else {
                @Suppress("DEPRECATION")
                enterPictureInPictureMode()
            }
        } catch (e: Exception) {
            false
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        // Beritahu halaman HTML supaya menyembunyikan header/tab dan menyisakan
        // konten saja selagi ditampilkan di jendela mini.
        webView.evaluateJavascript(
            "if(window.setPipMode) setPipMode(${isInPictureInPictureMode});", null
        )
    }

    private fun startBubbleOverlayAndMinimize() {
        BubbleService.show(this)
        moveTaskToBack(true)
    }

    /** Jembatan antara JavaScript (WebView) dan kode native Android. */
    inner class WebAppBridge {
        @JavascriptInterface
        fun minimizeToOverlay() {
            runOnUiThread { requestMinimizeToBubble() }
        }

        @JavascriptInterface
        fun isNativeOverlaySupported(): Boolean = true
    }
}
