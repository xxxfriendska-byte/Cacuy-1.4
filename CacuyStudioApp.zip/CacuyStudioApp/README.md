# Cacuy Studio — APK dengan Jendela Mini Mengambang (Picture-in-Picture)

Project Android Studio ini membungkus `cacuy-studio-app.html` ke dalam WebView,
lalu menambahkan kemampuan **jendela mini mengambang di atas aplikasi lain**
menggunakan **Picture-in-Picture (PiP)** bawaan Android — jenis jendela mengambang
yang sama seperti dipakai YouTube / video player untuk menampilkan pratinjau
konten sambil tetap bisa buka app lain. Ini persis seperti contoh gambar jendela
kecil mengambang yang kamu kirim — bukan cuma bubble ikon bulat kecil.

Kalau perangkat ternyata tidak mendukung PiP sama sekali (sangat jarang di HP
modern), app otomatis jatuh ke mode cadangan berupa bubble ungu ikon bulan yang
butuh izin "Display over other apps".

## Cara pakai

1. **Buka project ini di Android Studio** (File → Open → pilih folder `CacuyStudioApp`).
   Biarkan Android Studio melakukan Gradle Sync (butuh koneksi internet pertama kali
   untuk mengunduh dependency).
2. Sambungkan HP Android (aktifkan USB Debugging) atau pakai emulator Android 8+.
3. Klik **Run ▶** di Android Studio untuk install & jalankan.
4. Tekan tombol **"🗕 Kecilkan aplikasi"** di dalam app. Tampilan otomatis mengecil
   jadi jendela mini portrait yang tetap mengambang di layar — bisa digeser ke
   pojok mana saja — **tanpa perlu izin tambahan apa pun** (PiP adalah fitur resmi
   Android, tidak seperti overlay bubble yang butuh izin khusus).
5. Saat masuk mode mini, header dan tab disembunyikan otomatis supaya konten
   (hasil generate/preview) lebih terlihat jelas di jendela kecil.
6. Ketuk jendela mini untuk membuka lagi tampilan penuh Cacuy Studio — proses
   generate yang sedang berjalan (termasuk hitungan detik status "waiting...")
   **tetap lanjut**, tidak reset, karena WebView tidak pernah benar-benar ditutup.

## Struktur penting

- `app/src/main/assets/www/cacuy-studio-app.html` — ini file app kamu. Kalau nanti
  ada update HTML, **ganti file ini** lalu build ulang APK-nya.
- `app/src/main/java/com/cacuystudio/app/MainActivity.kt` — activity utama berisi
  WebView + jembatan JS (`AndroidBridge`) ke kode native.
- `app/src/main/java/com/cacuystudio/app/BubbleService.kt` — service yang
  menggambar bubble ungu mengambang & menanganinya (drag, tap untuk buka lagi).
- `AndroidManifest.xml` — berisi izin `SYSTEM_ALERT_WINDOW` (overlay) dan
  `FOREGROUND_SERVICE` (supaya proses tetap hidup saat diminimize).

## Cara kerja jendela mininya (ringkas)

1. Tombol "Kecilkan aplikasi" di HTML memanggil `window.AndroidBridge.minimizeToOverlay()`
   — ini sudah otomatis terhubung, tidak perlu ubah apa-apa lagi di HTML.
2. `MainActivity` memanggil `enterPictureInPictureMode()` bawaan Android — sistem
   yang mengurus semua animasi & posisi jendela mengambangnya, jadi hasilnya mulus
   dan konsisten di semua HP.
3. Saat mode PiP aktif, Android memanggil `onPictureInPictureModeChanged()`, yang
   lalu mengirim perintah ke JavaScript (`setPipMode(true)`) supaya HTML
   menyembunyikan header/tab dan menyisakan konten saja.
4. WebView & semua proses JS (polling status generate, timer detik) tetap hidup
   normal selama di mode PiP — tidak reset.
5. Ketuk jendela mini untuk kembali ke ukuran penuh; `setPipMode(false)` dipanggil
   lagi untuk mengembalikan tampilan header/tab.
6. `BubbleService.kt` (bubble ikon bulan ☾, butuh izin overlay) tetap disimpan di
   project sebagai **cadangan otomatis** untuk perangkat langka yang tidak
   mendukung PiP sama sekali.

## Build APK untuk dibagikan (release)

Di Android Studio: **Build → Generate Signed Bundle / APK** → pilih APK → ikuti
wizard untuk membuat / memakai keystore penandatanganan → pilih build type
`release`. File APK hasil akan ada di `app/release/app-release.apk`.

## Catatan

- `minSdk 24` (Android 7.0) ke atas — cakupan hampir semua HP Android yang masih dipakai.
- Kalau HP menjalankan Android 6 (API 23) ke bawah, perilaku izin overlay sedikit
  berbeda (otomatis diberikan tanpa dialog) — sudah ditangani oleh kode yang sama.
- Ikon app (mipmap) sudah dibuatkan versi sederhana bertema ungu + bulan senada
  dengan bubble di HTML. Silakan ganti dengan logo asli kalau ada.
